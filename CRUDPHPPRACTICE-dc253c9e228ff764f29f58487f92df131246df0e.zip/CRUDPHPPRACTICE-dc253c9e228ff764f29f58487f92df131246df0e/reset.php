<?php
session_start();
session_destroy();
header("Location:users_index.php");
?>
