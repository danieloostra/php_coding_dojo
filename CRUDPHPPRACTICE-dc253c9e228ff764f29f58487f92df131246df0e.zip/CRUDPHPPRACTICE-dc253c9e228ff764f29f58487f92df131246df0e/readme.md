This is a quick example of using PHPs SESSION to store a bunch of info.  Quickly, we are going to use a database to do all of this storage.

Your teams goal this morning is to fix update, add a header("Location:users_index.php") on every page, and add an input for another aspect of user that can be both created and edited.  This will require editing at least: new.php, and edit.php, and possibly update.php!  
